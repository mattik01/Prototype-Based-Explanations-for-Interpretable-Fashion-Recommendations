# Infrastructure Reference

This project uses a multi-device setup to separate development from GPU-intensive training. The **laptop** is the primary development machine — code editing, debugging, small CPU tests, and all Claude Code interaction happens here. The **GPU machine** is a Windows desktop with an RTX 4070 Ti SUPER, used exclusively for training runs and hyperparameter optimization. It is powered off when not in use and woken remotely via Wake-on-LAN.

Since the home router (TP-Link Deco mesh) lacks static ARP entries, it can't deliver WoL packets to a powered-off machine. A **phone relay** — a Samsung Galaxy S10 running Termux, always on and always connected to the local WiFi — sits on the LAN and sends WoL magic packets directly. All three devices are connected via a **Tailscale VPN**, so SSH access works from anywhere (home, campus, mobile hotspot) without port forwarding or dynamic DNS.

The workflow: develop on the laptop, push to git, wake the GPU machine, pull and train there, push results back. Claude Code skills (`/gpupc-start`, `/gpupc-stop`) automate the wake/shutdown cycle.

```
┌──────────────┐     Tailscale      ┌──────────────┐     LAN WoL      ┌──────────────┐
│    Laptop    │◄──────────────────►│  Phone Relay │────────────────►│ GPU Machine  │
│  (develop)   │     SSH + WoL      │  (always-on) │   magic packet   │   (train)    │
└──────────────┘                    └──────────────┘                  └──────────────┘
```

## Tailscale Network

| Device | Tailscale IP | Role |
|---|---|---|
| Laptop | `100.117.90.113` | Development |
| GPU machine | `100.85.86.56` | Training |
| Phone relay | `100.71.183.60` | WoL relay |

## Operations

| Action | Command |
|---|---|
| Wake GPU machine | `/gpupc-start` or `bash Master/sensitive/wake_gpu.sh` |
| Shutdown GPU machine | `/gpupc-stop` or `bash Master/sensitive/shutdown_gpu.sh` |
| SSH into GPU machine | `ssh gpu` |
| SSH into phone relay | `ssh termux-tailscale` |
| Manual WoL | `ssh termux-tailscale "python ~/wol_gpu.py"` |

---

## Laptop

| Property | Value |
|---|---|
| Hostname | `mattik01-Lenovo-ThinkBook-15-IIL` |
| OS | Linux (Ubuntu) |
| User | `mattik01` |
| Tailscale IP | `100.117.90.113` |
| PyTorch | 1.9.1+cpu (CPU only) |

### SSH Key

- Path: `~/.ssh/id_ed25519` (ed25519)
- Public: `ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIMv+5wZd1xCBE+dB0g6rldPaCH2/+q+uxoqN52fofyjE mattik01@thinkbook`

### SSH Config (`~/.ssh/config`)

```
Host gpu
    HostName 100.85.86.56
    User glaes
    IdentityFile ~/.ssh/id_ed25519
    ServerAliveInterval 60
    ServerAliveCountMax 3

Host termux
    HostName localhost
    Port 8022
    User u0_a317

Host termux-wifi
    HostName 192.168.68.51
    Port 8022
    User u0_a317

Host termux-tailscale
    HostName 100.71.183.60
    Port 8022
    User u0_a317
```

### Conda

```bash
conda activate protomf
```

CPU-only env, pip-installed. Bottleneck 1.3.4 (build fix), protobuf 3.20.0 (Ray 1.6.0 compat).

---

## GPU Machine

| Property | Value |
|---|---|
| Hostname | `DESKTOP-715IF4P` |
| OS | Windows 10/11 |
| GPU | NVIDIA GeForce RTX 4070 Ti SUPER (16 GB VRAM) |
| CUDA | 12.7, Driver 566.36 |
| Motherboard | MSI PRO B650-S WIFI (MS-7E26) |
| SSH user | `glaes` |

### Network

| Interface | Address |
|---|---|
| LAN IP | `192.168.68.58` (static) |
| Tailscale IP | `100.85.86.56` |
| MAC | `D8:43:AE:B3:D7:3D` |
| Gateway | `192.168.68.1` (TP-Link Deco mesh) |
| DNS | `1.1.1.1`, `8.8.8.8` |

### Services (Automatic start)

| Service | Purpose |
|---|---|
| `sshd` | OpenSSH Server |
| `Tailscale` | VPN (unattended mode enabled) |

### BIOS (access with `Del` at boot)

- Resume by PCI-E Device → `Enabled` (WoL)
- Restore after AC Power Loss → `Power On`
- ErP Ready → `Disabled`

### Power

```powershell
powercfg /hibernate off
powercfg /change standby-timeout-ac 0
powercfg /change monitor-timeout-ac 0
```

### SSH Key Auth

`sshd_config` (`C:\ProgramData\ssh\sshd_config`) — these lines must be **commented out**:
```
#Match Group administrators
#       AuthorizedKeysFile __PROGRAMDATA__/ssh/administrators_authorized_keys
```
Keys go in `C:\Users\glaes\.ssh\authorized_keys`.

### Post-Reboot Checklist

```powershell
Get-Service sshd, Tailscale | Format-Table Name, Status, StartType
tailscale ip -4
nvidia-smi
```

---

## Phone Relay

| Property | Value |
|---|---|
| Device | Samsung Galaxy S10 |
| Termux user | `u0_a317` |
| SSH port | `8022` |
| WiFi IP | `192.168.68.51` (DHCP, may change) |
| Tailscale IP | `100.71.183.60` |

### WoL Script (`~/wol_gpu.py` on phone)

```python
import socket

MAC = "D8:43:AE:B3:D7:3D"
TARGETS = ["192.168.68.58", "255.255.255.255"]
PORT = 9

def send_wol(mac, targets=TARGETS, port=PORT):
    mac_bytes = bytes.fromhex(mac.replace(":", "").replace("-", ""))
    magic = b"\xff" * 6 + mac_bytes * 16
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        for target in targets:
            s.sendto(magic, (target, port))
            print(f"WoL magic packet sent to {mac} via {target}:{port}")

if __name__ == "__main__":
    send_wol(MAC)
```

### SSH Keys Authorized on Phone

```
ssh-ed25519 AAAAC3... glaes@DESKTOP-715IF4P
ssh-ed25519 AAAAC3... mattik01@thinkbook
```

### After Phone Reboot

Termux services don't survive reboots. Re-run:
```bash
sshd
termux-wake-lock
```
Tailscale (Android app) reconnects automatically.

---

## Troubleshooting

| Issue | Fix |
|---|---|
| GPU machine unreachable after WoL | Check Tailscale is in unattended mode; verify `Get-Service Tailscale` |
| SSH refused on GPU machine | Verify `Get-Service sshd`; check `sshd_config` admin key override |
| SSH refused on phone | Run `sshd` in Termux |
| WoL not received by GPU | Verify `wol_gpu.py` targets `192.168.68.58` (direct IP) |
| Phone WiFi IP changed | `ssh termux-tailscale "ip addr show wlan0"`, update SSH config |
| Tailscale not connecting on phone | Open Tailscale app, ensure enabled |
| USB SSH to phone not working | `adb forward tcp:8022 tcp:8022` |
