#!/bin/bash
# Wake the GPU machine via Termux phone relay, then verify it comes online.
# If already awake, checks for other logged-in users and warns.

GPU_IP="100.85.86.56"
RELAY_IP="100.71.183.60"
SSH_USER="glaes"
MAX_ATTEMPTS=12
WAIT_SECONDS=10

# --- Check if already awake ---
echo "Checking if GPU machine is already online..."
if ping -c 1 -W 3 "$GPU_IP" &>/dev/null; then
    if ssh -o ConnectTimeout=5 -o BatchMode=yes gpu "echo ok" &>/dev/null; then
        echo "GPU machine is ALREADY online and SSH is ready."

        # Check for other logged-in users
        echo "Checking for active user sessions..."
        sessions=$(ssh -o ConnectTimeout=5 gpu "query user" 2>/dev/null)
        if [ $? -eq 0 ] && [ -n "$sessions" ]; then
            # Filter out our own SSH session and the header line
            other_users=$(echo "$sessions" | tail -n +2 | grep -v "^>*${SSH_USER}.*rdp-tcp" | grep -v "^$")
            console_sessions=$(echo "$sessions" | tail -n +2 | grep -i "console")

            if [ -n "$console_sessions" ]; then
                echo ""
                echo "╔══════════════════════════════════════════════════════════╗"
                echo "║  ⚠  WARNING: Someone is logged in at the CONSOLE!      ║"
                echo "╚══════════════════════════════════════════════════════════╝"
                echo ""
                echo "Active sessions:"
                echo "$sessions"
                echo ""
                echo "A user may be physically using the machine."
                echo "Your SSH session will NOT interfere with their work,"
                echo "but be aware someone is actively using the PC."
            else
                echo "No console session detected. Machine appears idle."
                echo "Active sessions:"
                echo "$sessions"
            fi
        else
            echo "Could not query user sessions (command may not be available)."
        fi

        exit 0
    else
        echo "Machine responds to ping but SSH not available."
        echo "Sending WoL packet anyway to try to fully wake it..."
    fi
else
    echo "Machine is offline. Proceeding with wake-up."
fi

# --- Check phone relay reachability ---
echo "Checking phone relay (termux-tailscale)..."
if ! ping -c 1 -W 5 "$RELAY_IP" &>/dev/null; then
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║  ✗  Phone relay is NOT responding to ping!              ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo "  Possible causes:"
    echo "    - Phone is off or in airplane mode"
    echo "    - Tailscale is not running on the phone"
    echo "    - Termux is not running or was killed by Android"
    echo "    - Phone has no network connectivity"
    echo "  Try: open Tailscale on the phone, then re-run this script."
    exit 1
fi
echo "  Phone relay is reachable."

# Verify SSH to relay works
echo "Verifying SSH to phone relay..."
if ! ssh -o ConnectTimeout=5 -o BatchMode=yes termux-tailscale "echo ok" &>/dev/null; then
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║  ✗  Phone relay responds to ping but SSH failed!        ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo "  Possible causes:"
    echo "    - sshd not running in Termux (run 'sshd' in Termux)"
    echo "    - SSH key not authorized on the phone"
    echo "    - Termux was restarted (sshd doesn't auto-start)"
    exit 1
fi
echo "  SSH to phone relay OK."

# --- Send WoL ---
echo "Sending WoL packet..."
ssh termux-tailscale "python ~/wol_gpu.py"

echo "Waiting for GPU machine to respond to ping..."
for i in $(seq 1 $MAX_ATTEMPTS); do
    sleep $WAIT_SECONDS
    if ping -c 1 -W 3 "$GPU_IP" &>/dev/null; then
        echo "  Ping OK. Checking SSH..."
        if ssh -o ConnectTimeout=5 -o BatchMode=yes gpu "echo ok" &>/dev/null; then
            echo "GPU machine is online and SSH is ready."
            exit 0
        else
            echo "  Ping responds but SSH not yet available. Waiting..."
        fi
    else
        echo "  Attempt $i/$MAX_ATTEMPTS — not yet reachable..."
    fi
done

# Final status report
if ping -c 1 -W 3 "$GPU_IP" &>/dev/null; then
    echo "PARTIAL: GPU machine responds to ping but SSH is not available."
    echo "  The machine may have booted without starting sshd (known issue)."
    echo "  Fix: log in at the console, or apply 'powercfg /change standby-timeout-ac 0'."
    exit 2
else
    echo "FAILED: GPU machine did not respond after $((MAX_ATTEMPTS * WAIT_SECONDS)) seconds."
    echo "  Check: phone relay reachable? ('ssh termux-tailscale') Machine has power?"
    exit 1
fi
