#!/bin/bash
# Clean shutdown of the GPU machine via SSH, then verify it goes offline.
# Checks for other logged-in users and asks for confirmation before proceeding.

GPU_IP="100.85.86.56"
SSH_USER="glaes"
MAX_ATTEMPTS=12
WAIT_SECONDS=10
RETRIES=3

# --- Check SSH connectivity first ---
echo "Checking SSH connectivity..."
if ! ssh -o ConnectTimeout=5 -o BatchMode=yes gpu "echo ok" &>/dev/null; then
    echo "Cannot reach GPU machine via SSH. Is it running?"
    exit 1
fi

# --- Check for other logged-in users ---
echo "Checking for active user sessions..."
sessions=$(ssh -o ConnectTimeout=5 gpu "query user" 2>/dev/null)
has_other_users=false

if [ $? -eq 0 ] && [ -n "$sessions" ]; then
    echo ""
    echo "Active sessions on GPU machine:"
    echo "$sessions"
    echo ""

    # Check for console sessions (someone physically at the PC)
    console_sessions=$(echo "$sessions" | tail -n +2 | grep -i "console")

    if [ -n "$console_sessions" ]; then
        has_other_users=true
        echo "╔══════════════════════════════════════════════════════════════╗"
        echo "║  ⚠  WARNING: Someone is logged in at the CONSOLE!          ║"
        echo "║  Shutting down will TERMINATE their session and any         ║"
        echo "║  unsaved work will be LOST!                                 ║"
        echo "╚══════════════════════════════════════════════════════════════╝"
        echo ""
    fi
else
    echo "Could not query user sessions. Proceeding with caution."
fi

# --- Ask for confirmation ---
if $has_other_users; then
    echo "Another user appears to be actively using this machine."
    read -p "Are you SURE you want to shut down? (yes/no): " confirm
else
    read -p "Proceed with shutdown? (y/n): " confirm
fi

case "$confirm" in
    y|yes|Y|YES)
        echo "Proceeding with shutdown..."
        ;;
    *)
        echo "Shutdown cancelled."
        exit 0
        ;;
esac

# --- Shutdown loop ---
for r in $(seq 1 $RETRIES); do
    echo "Sending shutdown command (attempt $r/$RETRIES)..."
    ssh -o ConnectTimeout=5 gpu "shutdown /s /t 0" 2>/dev/null

    echo "Waiting for GPU machine to go offline..."
    for i in $(seq 1 $MAX_ATTEMPTS); do
        sleep $WAIT_SECONDS
        ssh_up=false
        ping_up=false
        ssh -o ConnectTimeout=5 -o BatchMode=yes gpu "echo ok" &>/dev/null && ssh_up=true
        ping -c 1 -W 3 "$GPU_IP" &>/dev/null && ping_up=true

        if ! $ssh_up && ! $ping_up; then
            echo "GPU machine is offline (no SSH, no ping). Shutdown confirmed."
            exit 0
        fi

        status=""
        $ping_up && status="ping: up"
        $ssh_up && status="$status ssh: up"
        echo "  Attempt $i/$MAX_ATTEMPTS — still reachable ($status)"
    done

    echo "Machine still online after $((MAX_ATTEMPTS * WAIT_SECONDS)) seconds."
done

echo "FAILED: GPU machine did not shut down after $RETRIES retries."
echo "  Try: ssh gpu, then run 'shutdown /s /t 0' manually."
exit 1
